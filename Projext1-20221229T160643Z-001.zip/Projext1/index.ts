const q = 1;
let str : string  = 'string!';
str = "NazzikMart"