var q = 1;
var str = 'string!';
str = "NazzikMart";
